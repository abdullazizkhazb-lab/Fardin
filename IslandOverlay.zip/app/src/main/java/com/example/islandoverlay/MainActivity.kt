package com.example.islandoverlay

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var offsetLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        root.addView(button("1. Разрешить поверх других окон") { openOverlaySettings() })
        root.addView(button("Показать остров") { startIsland() })
        root.addView(button("Скрыть остров") { stopIsland() })

        offsetLabel = TextView(this).apply { setPadding(0, pad, 0, 0) }
        root.addView(offsetLabel)

        val saved = prefs().getInt(OverlayService.KEY_OFFSET_DP, OverlayService.DEFAULT_OFFSET_DP)
        updateOffsetLabel(saved)
        root.addView(SeekBar(this).apply {
            max = 100
            progress = saved
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs().edit().putInt(OverlayService.KEY_OFFSET_DP, p).apply()
                    updateOffsetLabel(p)
                    if (OverlayService.running) {
                        startService(Intent(this@MainActivity, OverlayService::class.java))
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        root.addView(TextView(this).apply {
            text = "\nXiaomi / MIUI 14 — обязательно:"
            textSize = 15f
        })
        root.addView(button("2. MIUI: всплывающие окна и фон") { openMiuiPermissions() })
        root.addView(button("3. MIUI: автозапуск") { openMiuiAutostart() })
        root.addView(button("4. Батарея: без ограничений") { openBatterySettings() })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        status.text = "Поверх окон: " + (if (overlay) "разрешено ✔" else "НЕ разрешено ✘") +
            "\nОстров: " + (if (OverlayService.running) "показан" else "скрыт") +
            "\nУстройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}"
    }

    private fun updateOffsetLabel(dp: Int) {
        offsetLabel.text = "Отступ сверху: $dp dp (подберите под свой экран)"
    }

    private fun prefs() = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)

    private fun startIsland() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала разрешите показ поверх других окон")
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        status.postDelayed({ refreshStatus() }, 400)
    }

    private fun stopIsland() {
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        status.postDelayed({ refreshStatus() }, 400)
    }

    private fun openOverlaySettings() {
        startSafe(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    /** MIUI: экран разрешений приложения (всплывающие окна в фоне и т.д.). */
    private fun openMiuiPermissions() {
        val miui = Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", packageName)
        startSafe(miui, fallback = appDetails())
    }

    /** MIUI: автозапуск. */
    private fun openMiuiAutostart() {
        val i = Intent().setComponent(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
        )
        startSafe(i, fallback = appDetails())
    }

    private fun openBatterySettings() {
        startSafe(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), fallback = appDetails())
    }

    private fun appDetails() =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

    private fun startSafe(intent: Intent, fallback: Intent? = null) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(fallback ?: appDetails())
            } catch (e2: Exception) {
                toast("Не удалось открыть настройки")
            }
        }
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
