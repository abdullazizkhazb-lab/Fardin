package com.example.islandoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Рисует «остров» поверх экрана (TYPE_APPLICATION_OVERLAY).
 * Работает на Samsung One UI и Xiaomi MIUI 14 / HyperOS, если выданы разрешения
 * (см. MainActivity и README).
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var islandView: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (islandView == null) showIsland() else updatePosition()
        return START_STICKY
    }

    private fun showIsland() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            // Разрешаем рисовать в зоне выреза камеры (Samsung / Xiaomi)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            y = offsetPx()
        }
        params = lp

        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#111111"))
            cornerRadius = dp(30).toFloat()
        }

        val label = TextView(this).apply {
            text = getString(R.string.island_text)
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }

        val container = FrameLayout(this).apply {
            background = bg
            addView(label)
            setOnClickListener {
                // Нажатие на остров: открыть приложение
                startActivity(
                    Intent(this@OverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        islandView = container
        wm.addView(container, lp)
    }

    private fun updatePosition() {
        val lp = params ?: return
        lp.y = offsetPx()
        islandView?.let { windowManager?.updateViewLayout(it, lp) }
    }

    private fun offsetPx(): Int {
        val dp = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_OFFSET_DP, DEFAULT_OFFSET_DP)
        return dp(dp)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Island", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun startAsForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Island работает")
            .setContentText("Нажмите, чтобы открыть настройки")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        running = false
        islandView?.let { runCatching { windowManager?.removeView(it) } }
        islandView = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.islandoverlay.STOP"
        const val PREFS = "island"
        const val KEY_OFFSET_DP = "offset_dp"
        const val DEFAULT_OFFSET_DP = 6
        private const val CHANNEL_ID = "island"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }
}
